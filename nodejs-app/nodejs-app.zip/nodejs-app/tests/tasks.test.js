const request = require('supertest');
const createApp = require('../src/app');

const app = createApp();

describe('Health check', () => {
  it('GET /health returns ok status and version', async () => {
    const res = await request(app).get('/health');
    expect(res.statusCode).toBe(200);
    expect(res.body.status).toBe('ok');
    expect(res.body.version).toBeDefined();
  });
});

describe('Tasks API', () => {
  it('GET /api/tasks returns an array with the seeded task', async () => {
    const res = await request(app).get('/api/tasks');
    expect(res.statusCode).toBe(200);
    expect(Array.isArray(res.body)).toBe(true);
    expect(res.body.length).toBeGreaterThan(0);
  });

  it('POST /api/tasks creates a new task', async () => {
    const res = await request(app).post('/api/tasks').send({ title: 'Write tests' });
    expect(res.statusCode).toBe(201);
    expect(res.body.title).toBe('Write tests');
    expect(res.body.done).toBe(false);
  });

  it('POST /api/tasks rejects missing title', async () => {
    const res = await request(app).post('/api/tasks').send({});
    expect(res.statusCode).toBe(400);
  });

  it('PUT /api/tasks/:id updates an existing task', async () => {
    const created = await request(app).post('/api/tasks').send({ title: 'Temp task' });
    const res = await request(app)
      .put(`/api/tasks/${created.body.id}`)
      .send({ done: true });
    expect(res.statusCode).toBe(200);
    expect(res.body.done).toBe(true);
  });

  it('DELETE /api/tasks/:id removes a task', async () => {
    const created = await request(app).post('/api/tasks').send({ title: 'Delete me' });
    const res = await request(app).delete(`/api/tasks/${created.body.id}`);
    expect(res.statusCode).toBe(204);
  });

  it('GET /api/tasks/:id returns 404 for unknown id', async () => {
    const res = await request(app).get('/api/tasks/999999');
    expect(res.statusCode).toBe(404);
  });
});
