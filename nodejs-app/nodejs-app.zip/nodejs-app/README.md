# Task Manager API

A small demo REST API used to walk through Node.js software packaging practices
(dependency management, versioning, environment separation, build artifacts,
verification, and dependency auditing).

## Quick start

```bash
npm install
npm run dev
```

Full documentation is built out progressively as part of this packaging project.
