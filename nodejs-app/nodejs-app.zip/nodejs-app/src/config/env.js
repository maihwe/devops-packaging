require('dotenv').config();

// Centralizing config here means the rest of the app never reads process.env
// directly — this is what lets the same package run unmodified across
// dev / staging / production, with only environment variables changing.
const config = {
  env: process.env.NODE_ENV || 'development',
  port: parseInt(process.env.PORT, 10) || 3000,
  logLevel: process.env.LOG_LEVEL || 'dev',
};

module.exports = config;
