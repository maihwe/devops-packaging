const createApp = require('./app');
const config = require('./config/env');

const app = createApp();

app.listen(config.port, () => {
  console.log(`Task Manager API running in ${config.env} mode on port ${config.port}`);
});
